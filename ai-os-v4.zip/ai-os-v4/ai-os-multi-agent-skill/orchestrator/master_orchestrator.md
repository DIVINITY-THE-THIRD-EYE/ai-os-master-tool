# Master Orchestrator Specification (`master_orchestrator.md`)

**Component Name:** AI OS v4 Master Orchestrator  
**Version:** 4.0.0  
**Package Path:** `orchestrator/master_orchestrator.md`  
**State Machine Ref:** `orchestrator/state_machine.yaml`  
**Escalation Matrix Ref:** `orchestrator/escalation_matrix.yaml`  

---

## 1. Executive Summary & Role Definition

The **Master Orchestrator** is the core autonomous decision engine of the **AI Operating System v4 (`ai-os-multi-agent-skill`)**. It is responsible for end-to-end task lifecycle management, state transitions, dynamic subagent dispatch, verification gating, fault escalation, and system recovery.

Operating as a deterministic controller, the Master Orchestrator binds together 13 specialized agents (A01 through A13), 6 operational workflows, multi-tiered runtime policies, and zero-trust quality gates into a coherent, self-healing multi-agent ecosystem.

---

## 2. Core Mission & Scope of Authority

### Core Mission
To receive complex, multi-faceted engineering, architecture, software construction, research, or operational requests; decompose them into deterministic execution plans; execute them across specialized autonomous subagents; continuously verify artifact quality and policy compliance; and deliver fully validated, governance-compliant outputs.

### Scope of Authority
1. **State Machine Management:** Sole authority to transition the system between the 10 formal states (`INIT`, `PLANNING`, `DECOMPOSITION`, `EXECUTION`, `VERIFICATION`, `ESCALATION`, `RECOVERY`, `RELEASE`, `COMPLETE`, `FAILED`).
2. **Subagent Delegation:** Authority to spawn, assign, evaluate, reassign, or terminate instances of Agents A01 through A13.
3. **Resource & Thread Control:** Authority to allocate CPU credits, concurrency slots, memory buffers, and tool permissions under `policies/execution_policy.yaml`.
4. **Quality Gate Enforcement:** Authority to accept or reject work products produced by execution agents based on automated quality gate scores from `quality/quality_gates.yaml`.
5. **Escalation & Intervention:** Authority to trigger automated recovery protocols or halt execution for human approval under `orchestrator/escalation_matrix.yaml` and `policies/approval_policy.yaml`.

---

## 3. Master Orchestrator Architecture & Component Topology

```
+-----------------------------------------------------------------------------------+
|                                MASTER ORCHESTRATOR                                |
|                                                                                   |
|  +-------------------+   +--------------------+   +----------------------------+  |
|  | State Machine Engine|   | Dispatch Controller|   | Quality Gating Controller  |  |
|  +---------+---------+   +---------+----------+   +-------------+--------------+  |
|            |                       |                            |                 |
|  +---------v---------+   +---------v----------+   +-------------v--------------+  |
|  | Escalation Engine |   | Context & Memory   |   | Governance & Audit Logger  |  |
|  +-------------------+   +--------------------+   +----------------------------+  |
+-----------------------------------------+-----------------------------------------+
                                          |
        +---------------------------------+---------------------------------+
        |                                 |                                 |
+-------v-------+                 +-------v-------+                 +-------v-------+
|  PLANNING &   |                 |   EXECUTION   |                 | VERIFICATION  |
| DECOMPOSITION |                 |    ENGINE     |                 |  & GOVERNANCE |
|  (A01 - A03)  |                 |  (A04 - A05)  |                 |  (A06 - A13)  |
+---------------+                 +---------------+                 +---------------+
```

The Master Orchestrator comprises six internal subcomponents:

1. **State Machine Engine:** Executes transitions defined in `state_machine.yaml`. Ensures state consistency, validates guards, and logs transition events.
2. **Dispatch Controller:** Evaluates subtask DAG requirements, selects target agent specifications (A01–A13), formats context envelopes, and manages asynchronous worker execution.
3. **Quality Gating Controller:** Interacts with Agent A07 and `quality/quality_gates.yaml` to score outputs, evaluate pass/fail criteria, and enforce threshold constraints.
4. **Escalation Engine:** Interacts with Agent A10 and `escalation_matrix.yaml` to handle execution failures, SLA breaches, and unexpected systemic errors.
5. **Context & Memory Manager:** Controls access to Working, Session, Persistent, and Project memory tiers according to `policies/memory_policy.yaml`.
6. **Governance & Audit Logger:** Emits append-only structured telemetry and audit records via `platform/logging_pipeline.yaml` and `events/event_topics.yaml`.

---

## 4. Lifecycle Execution Pipeline & Step-by-Step Flow

```
[INIT] ---> [PLANNING] ---> [DECOMPOSITION] ---> [EXECUTION] ---> [VERIFICATION]
                                                     ^                 |
                                                     | (Pass/Fix)      v
[COMPLETE] <--- [RELEASE] <-------------------- [RECOVERY] <--- [ESCALATION]
                                                     |
                                                     v (Max Retries)
                                                 [FAILED]
```

### Phase 1: Initialization (`INIT`)
- Receive request envelope from CLI, IDE, API Gateway, or Event Broker.
- Create new task trace ID, allocate working memory buffer, initialize telemetry span.
- Evaluate security policy (`policies/security_policy.yaml`) for ingress validation.
- Transition to `PLANNING`.

### Phase 2: Requirements & Architecture Planning (`PLANNING`)
- Dispatch Agent A01 (Requirements Architect) to formalize scope and output functional requirements.
- Dispatch Agent A02 (Domain Planner) to define system architecture blueprint and component boundaries.
- Verify planning output completeness. Transition to `DECOMPOSITION`.

### Phase 3: Task Decomposition (`DECOMPOSITION`)
- Dispatch Agent A03 (Task Decomposer) to synthesize Directed Acyclic Graph (DAG) task structure.
- Define subtask dependencies, resource requirements, input/output schemas, and individual subtask SLAs.
- Validate DAG topology for circular dependencies. Transition to `EXECUTION`.

### Phase 4: Parallel & Gated Execution (`EXECUTION`)
- Dispatch Agent A04 (Execution Engineer) to schedule ready DAG nodes.
- Dispatch Agent A05 (Code & Artifact Builder) to generate code files, tests, scripts, and documentation artifacts.
- Monitor real-time execution telemetry, process memory usage, and execution timeouts (`policies/execution_policy.yaml`).
- Upon completion of DAG execution, transition to `VERIFICATION`.

### Phase 5: Gated Verification & Audit (`VERIFICATION`)
- Dispatch Agent A06 (Verification Engine) to run unit tests, integration tests, and syntax validation.
- Dispatch Agent A08 (Security Auditor) to perform SAST analysis and vulnerability checks.
- Dispatch Agent A07 (Quality Gatekeeper) to compute overall quality score using `quality/scoring_thresholds.yaml`.
- If Quality Score >= Threshold: Transition to `RELEASE`.
- If Quality Score < Threshold: Transition to `ESCALATION`.

### Phase 6: Escalation & Recovery (`ESCALATION` -> `RECOVERY`)
- Match failure pattern against `orchestrator/escalation_matrix.yaml` to determine severity (L1–L4).
- L1/L2: Dispatch Agent A10 (Failure & Recovery Specialist) to execute target patch, increment retry counter, and loop back to `EXECUTION`.
- L3: Pause execution, request elevated approval or specialist intervention.
- L4: Trigger system halt, log critical fault, transition to `FAILED`.
- If recovery succeeds within SLA: Transition back to `EXECUTION` or `VERIFICATION`.
- If recovery exceeds max retries: Transition to `FAILED`.

### Phase 7: Production Release & Documentation (`RELEASE`)
- Dispatch Agent A11 (Documentation & Handoff Engineer) to generate handoff report, release notes, and API specs.
- Dispatch Agent A13 (Governance Officer) to execute final regulatory compliance audit and issue certificate.
- Transition to `COMPLETE`.

### Phase 8: Continuous Learning Harvest (`POST-EXECUTION`)
- Asynchronously dispatch Agent A12 (Continuous Learning Engine) to harvest post-mortem insights, extract reusable patterns, and update prompt templates.

---

## 5. State Machine Linkage & Transition Rules

The Master Orchestrator binds directly to `orchestrator/state_machine.yaml`. Every state transition requires:
1. **Source State Validation:** Current state matches transition source.
2. **Trigger Event Authorization:** Valid trigger event emitted on `events/event_topics.yaml`.
3. **Guard Condition Evaluation:** Boolean guard expressions evaluated against runtime context (e.g., `dag_validated == true`, `quality_score >= 0.90`).
4. **Pre-Transition Action Execution:** Execution of registered exit actions on source state.
5. **Post-Transition Action Execution:** Execution of registered entry actions on target state.
6. **Audit Trail Recording:** Emission of `aios.state.transitioned` event with trace ID, old state, new state, trigger event, and guard results.

---

## 6. Subagent Dispatch Rules & Handoff Protocol

### Subagent Dispatch Rules
- **Capability Matching:** Match task requirements against agent skills declared in `skill.yaml`.
- **Isolation Boundary:** Run each subagent in a sandbox container/thread with dedicated working memory.
- **Context Injection:** Provide subagent with explicit task context envelope, relevant SOPs from `knowledge/sops/`, and target output schemas.
- **Timeout Management:** Enforce individual agent SLA limits. Kill subagent execution if timeout breached and trigger L2 Escalation.

### Standardized Handoff Protocol (`SOP-002`)
All agent-to-agent and agent-to-orchestrator handoffs must emit a structured handoff report adhering to `events/handoff_schema.json` containing 5 mandatory sections:
1. **Observation:** Verbatim output logs, file paths, line numbers, test results.
2. **Logic Chain:** Step-by-step reasoning connecting observations to conclusions.
3. **Caveats:** Assumptions, unverified areas, potential edge cases.
4. **Conclusion:** Scoped, actionable assessment and generated artifacts.
5. **Verification Method:** Exact shell commands or test scripts to reproduce and verify results.

---

## 7. Escalation Logic & SLA Boundary Handling

The Master Orchestrator continuously monitors runtime metrics against SLA boundaries defined in `orchestrator/escalation_matrix.yaml`:

- **Level 1 (L1 - Minor Anomaly):** Syntax error, missing import, minor format flaw.
  - *Action:* Automatic self-fix retry by execution agent (max 3 retries, SLA 60s).
- **Level 2 (L2 - Execution Regression):** Logic test failure, verification gate rejection, timeout breach.
  - *Action:* Route to Agent A10 (Recovery Specialist) for diagnostic patch and re-execution (max 2 retries, SLA 300s).
- **Level 3 (L3 - Major Fault):** Security vulnerability detected, architectural contradiction, policy breach.
  - *Action:* Route to Agent A13 (Governance Officer) / Human-in-the-loop approval gate (SLA 900s).
- **Level 4 (L4 - Critical System Halt):** Data corruption, unauthorized privilege escalation, unrecoverable environment fault.
  - *Action:* Immediate emergency freeze, state dump to persistent memory, transition to `FAILED` (SLA immediate).

---

## 8. Resilience, Fault Tolerance & Recovery Protocols

To guarantee zero data loss and deterministic fault recovery:

1. **State Persistence & Checkpointing:** Write state snapshots to `platform/storage_adapter.yaml` prior to every state transition.
2. **Idempotent Retry Execution:** Ensure all agent operations (file edits, test runs, code builds) are idempotent and side-effect free on retry.
3. **Context Rollback:** If recovery patch fails, roll back working memory and file workspace to the last known valid snapshot (`checkpoint_id`).
4. **Circuit Breakers:** If an execution agent fails 3 consecutive tasks, trip circuit breaker, mark agent instance degraded, and re-route tasks to standby worker instance.

---

## 9. Decision Logic, Arbitration & Approval Gate Management

When agents produce conflicting recommendations or low-confidence outputs:

1. **Confidence Thresholding:** Any agent output with confidence score < 0.85 requires automated secondary review by Agent A07 or Agent A08.
2. **Arbitration Engine:** The Master Orchestrator evaluates conflicting proposals against `knowledge/rules.yaml` and selects the option maximizing Quality Score and Security Compliance.
3. **Human Approval Gates:** Evaluated via `policies/approval_policy.yaml`. Mandatory human sign-off triggered for:
   - High-cost or production-impacting operations.
   - Unresolved L3 security vulnerabilities.
   - Final release deployment in Enterprise strict mode.

---

## 10. Security, Governance & Audit Trail Requirements

1. **Zero-Trust Privilege Boundary:** Agents receive principle-of-least-privilege read/write access limited to their specific assigned task directory.
2. **Secret Redaction:** Automatic inline scrubbing of API keys, passwords, and tokens before writing to logs, handoff reports, or telemetry events.
3. **Immutable Audit Logging:** Every decision, state transition, quality score, and agent handoff is written to an append-only JSON audit log (`platform/logging_pipeline.yaml`).
4. **Regulatory Compliance:** Verification against ISO/IEC 42001 and SOC 2 Type II audit guidelines managed by Agent A13.

---

## 11. Operational SLAs, Metrics & Telemetry Specification

The Master Orchestrator tracks key operational metrics emitted to `platform/telemetry_bridge.yaml`:

- **Orchestration Throughput:** Number of completed workflows per hour.
- **State Transition Latency:** P95 transition delay (< 50ms).
- **First-Pass Quality Yield (FPQY):** % of workflows completing without entering `ESCALATION` (Target >= 85%).
- **Mean Time to Recover (MTTR):** Average time spent in `RECOVERY` state (< 180s).
- **SLA Breach Rate:** % of subtasks exceeding defined SLA (< 1.0%).
