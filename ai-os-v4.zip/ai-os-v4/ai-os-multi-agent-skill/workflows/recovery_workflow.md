# AI OS Automated Error Recovery & Self-Healing Workflow Specification

## 1. Overview & Resilience Philosophy

The **AI OS Recovery Workflow** defines the automated procedures, state restoration protocols, retry strategies, and failure escalation paths executed when an agent task, system component, or workflow node encounters an unhandled error, timeout, state corruption, or policy violation.

### Core Recovery Principles
- **Self-Healing Automation**: The system attempts transparent, autonomous self-healing before escalating to human operators or marking a task as permanently failed.
- **State Checkpoint Isolation**: Task progress is checkpointed at every workflow state boundary. Recovery restores execution from the last validated checkpoint rather than re-running the entire workflow graph.
- **Adaptive Parameter Re-tuning**: When code generation or reasoning fails, recovery adjusts prompt generation parameters (e.g. lowering model sampling temperature, providing explicit error context, selecting a higher-tier LLM model).
- **Circuit Breaking & Fallback Isolation**: Repeated node failures isolate the malfunctioning sub-agent or component, preventing cascading failures across the execution cluster.

---

## 2. Fault Classification Taxonomy

Errors occurring during system operation are categorized into five distinct severity classes:

```
                  ┌──► Class 1: Transient Infrastructure Failure (Auto Retry + Backoff)
                  ├──► Class 2: Agent Code Generation / Logic Failure (Prompt Mutate + Retry)
[ System Fault ] ─┼──► Class 3: Context Truncation / State Corruption (Restore Checkpoint)
                  ├──► Class 4: Resource Exhaustion / Rate Limit (Queue Pause + Throttle)
                  └──► Class 5: Security / Policy Violation (Hard Stop + Escalation)
```

| Class ID | Error Category | Example Root Causes | Default Recovery Strategy | Max Retries |
| :--- | :--- | :--- | :--- | :--- |
| **Class 1** | Transient Infrastructure | Network socket timeout, DB connection pool busy, API 503 | Exponential Backoff with Jitter | 3 Retries |
| **Class 2** | Code / Logic Defect | Syntax error, failing unit test, lint violation, schema mismatch | Diagnostic Feedback Loop & Prompt Mutation | 3 Retries |
| **Class 3** | State / Memory Corruption | Invalid JSON state snapshot, context window overflow, broken link | State Snapshot Rollback & Context Pruning | 2 Retries |
| **Class 4** | Resource Exhaustion | Out of Memory (OOM), rate limit 429, API token quota exhaustion | Circuit Breaker Cooldown & Rate Throttling | 2 Retries |
| **Class 5** | Policy / Security Violation | Credential leak attempt, forbidden system call, governance breach | Immediate Workflow Halt & SecOps Escalation | 0 Retries |

---

## 3. Step-by-Step Automated Recovery Lifecycle

When an error occurs at any node in the execution graph, the Recovery Engine executes the following 5-step self-healing sequence:

```
[ Error Intercepted ]
          │
          ▼
┌────────────────────────────────────────────────────────┐
│ Step 1: Fault Identification & Classification         │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│ Step 2: State Snapshot Isolation & Checkpoint Capture  │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│ Step 3: Recovery Strategy Selection (Class 1 - 5)      │
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│ Step 4: Self-Healing Execution (Backoff / Mutate)      │
└─────────────────────────┬──────────────────────────────┘
                          │
             ┌────────────┴────────────┐
       Pass  │                         │ Fail (Retries Exhausted)
             ▼                         ▼
  [ Resume Workflow ]       [ Step 5: Escalation Matrix ]
```

### Step 1: Fault Identification & Classification
The error handling hook captures the exception, stack trace, failing node ID, and agent context. The error payload is evaluated against regex pattern matchers to determine its Class (Class 1 through 5).

### Step 2: State Snapshot Isolation & Checkpoint Capture
The system freezes the current execution context and retrieves the last known valid state checkpoint snapshot:
```json
{
  "checkpoint_id": "CHK-SESS9921-NODE05-V2",
  "node_id": "node_05_core_engineering",
  "timestamp": "2026-08-05T23:05:26Z",
  "variables": {
    "architecture_blueprint_ref": "s3://ai-os-state/blueprints/bp-88392.json",
    "completed_subtasks": ["ST1_DB_MIGRATION"]
  },
  "sha256_integrity": "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08"
}
```

### Step 3: Recovery Strategy Selection
- **Class 1 (Transient)**: Calculate backoff delay:
  $$t_{\text{sleep}} = \min(t_{\text{max}}, t_{\text{base}} \times 2^{\text{attempt}} + \text{rand}(0, 1))$$
- **Class 2 (Logic Defect)**: Extract exact compiler or test output, build diagnostic prompt, append explicit negative constraint, and lower model temperature ($T: 0.7 \rightarrow 0.2$).
- **Class 3 (State Failure)**: Flush short-term context cache, purge corrupt state key, re-hydrate context from `CHK-SESS9921-NODE05-V2`.
- **Class 4 (Exhaustion)**: Open Circuit Breaker for 300 seconds; pause node queue; re-route sub-tasks to secondary model endpoint.
- **Class 5 (Policy Breach)**: Immediately revoke worker permissions; isolate workspace directory; log incident to `policies/governance_policies.yaml`.

### Step 4: Self-Healing Execution
The Recovery Engine executes the selected strategy. If execution succeeds, the node emits `EVT_RECOVERY_SUCCESS` and resumes normal workflow execution.

### Step 5: Failure Escalation Matrix
If retries are exhausted or a Class 5 error occurs, the Recovery Engine triggers formal escalation:

```
                      [ Retries Exhausted ]
                                │
                                ▼
                   ┌──────────────────────────┐
                   │ Is Risk Score > 0.7 OR   │
                   │ Class 5 Policy Violation?│
                   └────────────┬─────────────┘
                      Yes       │       No
            ┌───────────────────┴──────────────────┐
            ▼                                      ▼
┌───────────────────────────────┐      ┌───────────────────────────────┐
│ Tier 2: Operator Human In-    │      │ Tier 1: Fallback Agent Re-     │
│ The-Loop (HITL) Alert         │      │ Delegation (A01 Master Swap)  │
└───────────────────────────────┘      └───────────────────────────────┘
```

---

## 4. State Restoration Mechanics & Memory Re-hydration

When re-hydrating a failed execution session:
1. **Purge Volatile Memory**: Wipe in-memory scratchpads and intermediate token caches.
2. **Download Verified Checkpoint**: Pull immutable checkpoint state from persistent storage.
3. **Re-establish Lock Table**: Re-claim distributed semaphores for required output files.
4. **Re-inject Context Baseline**: Inject system prompt, original architecture blueprint, and detailed error remediation instructions.

---

## 5. Escalation Notification Payload Schema

When escalating to a human operator or secondary orchestrator:
```json
{
  "escalation_event_id": "ESC-908123-FATAL",
  "task_id": "TASK-20260805-A92F",
  "failing_node": "node_08_qa_testing",
  "assigned_agent": "A05_Quality_Assurance_Testing",
  "error_class": "CLASS_2_LOGIC_DEFECT",
  "retry_count": 3,
  "last_error_message": "Line coverage 78.2% failed mandatory threshold of 85.0%",
  "escalation_tier": "TIER_2_HITL_INTERVENTION",
  "recommended_actions": [
    "Approve temporary coverage waiver for edge-case module",
    "Manually inject missing unit tests into tests/test_payment.py",
    "Trigger workflow resumption via POST /v1/orchestrator/resume"
  ],
  "context_snapshot_url": "https://console.ai-os.internal/recovery/sessions/SESS-9921"
}
```
