# AI OS Core Task Execution Workflow Specification

## 1. Overview & Architecture Principles

The **AI OS Core Task Execution Workflow** defines the deterministic, stateful lifecycle of complex engineering, analytical, and operational tasks dispatched across the 13 specialized agents of the multi-agent runtime environment. 

### Core Design Principles
1. **Deterministic State Progression**: Every task transitions through an explicit state machine with non-repudiable state snapshots.
2. **Parallel Scatter-Gather Processing**: Non-dependent tasks are dynamically parallelized across isolated agent execution threads.
3. **Shift-Left Verification**: Quality gates and security pre-checks occur prior to downstream artifact consumption.
4. **Context Isolation & Minimization**: Agents operate within scoped execution contexts, receiving only task-relevant inputs to prevent context window pollution and cross-agent state leakage.
5. **Zero-Trust Handshake Protocol**: Every message and artifact transferred between agents undergoes schema and assertion validation before acceptance.

---

## 2. Execution State Machine & Lifecycle Transitions

Tasks managed by the execution workflow transition through 12 formal states:

```
[ UNINITIALIZED ]
       │
       ▼
  [ QUEUED ] ──────────► [ INTAKE ]
                             │
                             ▼
                        [ PLANNING ]
                             │
                             ▼
                        [ DESIGNING ]
                             │
                             ▼
                        [ EXECUTING ] ◄──────┐ (Retry Loop)
                             │               │
                             ▼               │
                        [ VERIFYING ] ───────┘
                             │
                             ▼
                   [ RELEASE_PENDING ]
                             │
                             ▼
                        [ RELEASED ]
```

### State Definitions

| State Name | Responsibilities & Invariants | Trigger / Event | Next Valid States |
| :--- | :--- | :--- | :--- |
| `UNINITIALIZED` | Task payload received; context space created. | External dispatch API | `QUEUED` |
| `QUEUED` | Placed in priority execution queue; awaiting worker availability. | Resource allocation check | `INTAKE`, `HALTED` |
| `INTAKE` | `A01 Master Orchestrator` parses input, assigns session, computes risk score. | `EVT_TASK_INTAKE_STARTED` | `PLANNING`, `FAILED` |
| `PLANNING` | `A02 Task Planning` generates WBS tree and acyclic dependency DAG. | `EVT_PLANNING_COMPLETE` | `DESIGNING`, `RECOVERY` |
| `DESIGNING` | `A03 Architecture` produces system blueprint, APIs, and schemas. | `EVT_DESIGN_APPROVED` | `EXECUTING`, `RECOVERY` |
| `EXECUTING` | `A04 Core Engineering`, `A09 Data`, `A10 DevOps` implement code & infra. | `EVT_EXECUTION_DISPATCHED` | `VERIFYING`, `RECOVERY` |
| `VERIFYING` | `A05 QA`, `A06 Security`, `A07 Performance` run test matrix and scanners. | `EVT_VERIFICATION_STARTED` | `RELEASE_PENDING`, `EXECUTING`, `RECOVERY` |
| `RELEASE_PENDING` | `A11 Compliance` audits artifacts; awaiting approval thresholds. | `EVT_AUDIT_PASSED` | `RELEASED`, `HALTED` |
| `RELEASED` | `A13 Release` publishes artifacts and updates environment. | `EVT_RELEASE_PUBLISHED` | `COMPLETED` |
| `FAILED` | Terminal state for unrecoverable errors. | `EVT_FATAL_ERROR` | `RECOVERED` (Manual override) |
| `HALTED` | Temporarily paused for human-in-the-loop (HITL) intervention. | `EVT_HITL_PAUSE` | `EXECUTING`, `FAILED` |
| `RECOVERED` | Automated or manual recovery applied; context state restored. | `EVT_RECOVERY_SUCCESS` | `PLANNING`, `EXECUTING` |

---

## 3. Phase Specifications & Agent Interaction Patterns

### Phase 1: Task Intake & Context Initialization
- **Primary Agent**: `A01 Master Orchestrator`
- **Execution Mode**: Synchronous
- **Inputs**: Task specification payload (JSON/YAML), SLA requirement, Target Environment.
- **Processing Steps**:
  1. Validate payload structure against `task_specification_schema.json`.
  2. Compute initial task complexity index ($C \in [1, 10]$) and risk factor ($R \in [0.0, 1.0]$).
  3. Initialize persistent state session store with immutable execution token.
  4. Emit `EVT_TASK_INTAKE_STARTED` to the global Event Bus.
- **Outputs**: `task_session_id`, `execution_context_ref`, `initial_risk_score`.

### Phase 2: Work Breakdown Structure (WBS) & Dependency Mapping
- **Primary Agent**: `A02 Task Planning & Decomposition`
- **Execution Mode**: Sequential with Validation Sub-routine
- **Inputs**: `execution_context_ref`, Task Description, Business Goals.
- **Processing Steps**:
  1. Deconstruct macro requirement into granular sub-tasks ($ST_1, ST_2, \dots, ST_n$).
  2. Map directional dependencies between sub-tasks to form DAG matrix $D_{ij}$.
  3. Perform topological sort to detect and reject graph cycles.
  4. Assign optimal specialized agent ($A03$ through $A13$) to each sub-task based on capability matrix.
- **Outputs**: `wbs_tree.json`, `dependency_dag.yaml`, `agent_assignment_matrix.json`.

### Phase 3: Architectural Design & Security Pre-Check
- **Primary Agents**: `A03 System Architecture & Design`, `A06 Security & Vulnerability Analysis`
- **Execution Mode**: Coordinated Handshake
- **Processing Steps**:
  1. `A03` generates architectural blueprint, OpenAPI specifications, and data schemas.
  2. `A06` inspects architectural blueprint against security baseline (OWASP Top 10, Zero Trust boundaries).
  3. If security pre-check identifies structural flaws, `A06` issues rejection event `EVT_SECURITY_PRECHECK_REJECTED` with required mitigations back to `A03`.
  4. Upon approval, `A03` signs architectural blueprint and freezes schema state.
- **Outputs**: `architecture_blueprint.md`, `interface_contracts.yaml`, `security_baseline.yaml`.

### Phase 4: Parallel Execution Engine (Scatter-Gather)
- **Primary Agents**: `A04 Core Engineering`, `A09 Data Engineering`, `A10 DevOps & Infrastructure`
- **Execution Mode**: Concurrent Scatter-Gather
- **Processing Diagram**:

```
                  ┌──► [ A04 Core Engineering ] ───────┐
                  │    (Logic & Implementation)       │
                  │                                   │
[ Dispatcher ] ───┼──► [ A09 Data Engineering ] ──────┼──► [ Gather Barrier ]
                  │    (Database & Pipelines)         │
                  │                                   │
                  └──► [ A10 DevOps Infrastructure ] ─┘
                       (Containers & IaC)
```

- **Concurrency & Dependency Control**:
  - Independent tasks are executed concurrently up to max thread ceiling ($N_{\text{max}} = 4$).
  - Shared resource locks managed via Distributed Semaphore lock manager.
  - Sub-task outputs pushed to intermediate artifact vault upon completion.
  - Gather barrier waits for all parallel nodes to emit `EVT_SUBTASK_COMPLETED`.

---

## 4. State Persistence, Shared Memory & Artifact Passing

### Shared Memory Architecture
Agents exchange data using a two-tier memory architecture:
1. **Short-Term Context Memory**: In-memory key-value cache scoped to the current execution step. Stores prompt histories, immediate node responses, and local variables.
2. **Long-Term State Vault**: Cryptographically indexed object store containing immutable output artifacts (source code files, Dockerfiles, OpenAPI specs, test results).

### Handoff Protocol Specification
When transferring execution authority between agents:
```json
{
  "handoff_id": "HO-908234-A04-A05",
  "timestamp": "2026-08-05T23:05:26Z",
  "source_agent": "A04_Core_Engineering_Implementation",
  "target_agent": "A05_Quality_Assurance_Testing",
  "context_snapshot_uri": "s3://ai-os-state/sessions/SESS-9921/ho-908234.json",
  "artifacts": [
    {
      "path": "src/services/payment_engine.py",
      "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      "type": "SOURCE_CODE"
    }
  ],
  "execution_notes": "Implemented payment reconciliation logic with exponential retries."
}
```

---

## 5. Parallel Dispatch Mechanics & Synchronization

### Dispatch Engine Specifications
- **Queue Type**: Weighted Priority Queue (Urgency SLA $\times$ Risk Weighting).
- **Worker Allocation**: Agents operate as stateless worker instances hydrated with role-specific prompt templates and policy sets upon execution dispatch.
- **Deadlock Prevention**:
  - All resource locks acquire with explicit TTL (default: 300 seconds).
  - Cyclic dependency checks re-executed prior to every parallel dispatch wave.

---

## 6. Concrete Execution Scenarios

### Scenario A: Standard Feature Implementation
1. `A01` receives request for new API endpoint `POST /v1/orders/refund`.
2. `A02` breaks task into: DB Migration (`ST1`), Core Logic (`ST2`), IaC Route (`ST3`), E2E Test (`ST4`).
3. `A03` defines OpenAPI schema. `A06` passes security pre-check.
4. `A09` implements DB Migration (`ST1`) and `A04` implements Core Logic (`ST2`) in parallel.
5. `A05` executes test suite (Unit + Integration), achieving 92% coverage.
6. `A11` verifies compliance, `A13` publishes to staging environment.

### Scenario B: Emergency Patch Execution (Fast-Track)
1. `A01` detects high-priority bug ticket; flags SLA as `URGENT_SLA_30M`.
2. `A02` bypasses deep architectural redesign; routes directly to `A04` for targeted patch generation.
3. `A06` and `A05` run synchronous inline audit and regression suite in parallel.
4. `A13` deploys canary release to production upon `A11` auto-approval threshold match.
