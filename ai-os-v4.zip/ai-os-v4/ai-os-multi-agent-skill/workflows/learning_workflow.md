# AI OS Continuous Learning, Post-Mortem & Pattern Harvesting Workflow Specification

## 1. Overview & Learning Flywheel Architecture

The **AI OS Learning Workflow** establishes a continuous feedback loop that extracts structural insights, code design patterns, prompt optimizations, and failure post-mortems from live system execution. 

### Learning Flywheel Principles
- **Closed-Loop System Optimization**: Operational metrics, verification test results, and error logs are automatically mined to refine system prompts, SOPs, and agent decision matrices.
- **Automated Root Cause Analysis (RCA)**: Failed or degraded tasks undergo automated post-mortem extraction to isolate root causes and formulate preventative rules.
- **Pattern Harvesting**: Successful code architectures, reusable utility modules, and effective problem-solving strategies are cataloged into the central Pattern Library.
- **Safety-Gated Self-Improvement**: Dynamic updates to core prompts, runtime policies, or agent authority boundaries require formal regression benchmarking and optional human approval before deployment.

---

## 2. Continuous Learning Lifecycle

The learning workflow operates continuously across five synchronized phases:

```
[ Task Execution Telemetry & Traces ]
                 │
                 ▼
┌────────────────────────────────────────────────────────┐
│ Phase 1: Telemetry Ingestion & Feature Mining         │ (A12)
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│ Phase 2: Post-Mortem & Failure Taxonomy Extraction    │ (A12)
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│ Phase 3: Prompt & Metaprompt Optimization Loop        │ (A12 / A01)
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│ Phase 4: Architecture & SOP Pattern Harvesting        │ (A08 / A12)
└─────────────────────────┬──────────────────────────────┘
                          │
                          ▼
┌────────────────────────────────────────────────────────┐
│ Phase 5: Knowledge Base Indexing & Policy Evolution   │ (A11 / A12)
└────────────────────────────────────────────────────────┘
```

---

## 3. Phase Specifications

### Phase 1: Telemetry Ingestion & Feature Mining
- **Responsible Agent**: `A12 Continuous Learning & Reflection`
- **Inputs**: Token usage logs, step execution durations, agent handoff traces, error frequency metrics, QA coverage scores.
- **Processing**:
  1. Aggregate execution traces across completed and failed workflow sessions.
  2. Compute efficiency score $E_{\text{task}}$:
     $$E_{\text{task}} = \frac{\text{QualityPassRate} \times \text{CoveragePct}}{\text{TotalTokensUsed} \times \text{ExecutionTimeSeconds}}$$
  3. Identify outlier tasks ($E_{\text{task}}$ in bottom 10th percentile or top 10th percentile).

### Phase 2: Post-Mortem Extraction & Root Cause Analysis (RCA)
- **Responsible Agent**: `A12 Continuous Learning & Reflection`
- **RCA Methodology**: 5-Whys Analysis & Failure Tree Isolation.
- **Output Artifact**: Structured Post-Mortem Document (`post_mortem_SCHEMA.json`).
- **Post-Mortem Schema Sample**:
```json
{
  "post_mortem_id": "PM-20260805-091",
  "task_id": "TASK-20260805-B129",
  "failure_summary": "Core Engineering agent generated invalid SQL query syntax using obsolete Postgres dialect.",
  "root_cause_analysis": {
    "why_1": "Database migration script failed execution during QA verification.",
    "why_2": "SQL script contained JSONB syntax unsupported in Postgres 12.",
    "why_3": "Agent prompt lacked explicit target database version constraints.",
    "why_4": "Architectural blueprint did not specify Postgres major version in data schema contract.",
    "why_5": "Task Planning agent omitted database version parameter during initial WBS generation."
  },
  "corrective_actions": [
    {
      "action_type": "PROMPT_REFINEMENT",
      "target_agent": "A02_Task_Planning_Decomposition",
      "description": "Inject mandatory target_db_version field into WBS schema generator."
    },
    {
      "action_type": "ANTI_PATTERN_LOG",
      "target_library": "knowledge/anti_patterns/db_migrations.md",
      "description": "Catalog Postgres 12 JSONB migration syntax anti-pattern."
    }
  ]
}
```

### Phase 3: Prompt & Metaprompt Optimization Loop
- **Responsible Agents**: `A12 Continuous Learning & Reflection`, `A01 Master Orchestrator`
- **Optimization Strategy**:
  1. Identify system prompt sections correlated with high failure or retry rates.
  2. Generate candidate prompt variant $P_{\text{new}}$ using prompt mutation strategies (adding explicit constraints, structural formatting, zero-shot example updates).
  3. Execute A/B benchmark evaluation over standard test suite:
     $$\Delta \text{Performance} = \text{Score}(P_{\text{new}}) - \text{Score}(P_{\text{baseline}})$$
  4. If $\Delta \text{Performance} > +5.0\%$ and zero regressions occur, submit $P_{\text{new}}$ to release pipeline.

### Phase 4: Pattern Harvesting & Best Practice Extraction
- **Responsible Agents**: `A08 Technical Documentation`, `A12 Continuous Learning & Reflection`
- **Harvesting Triggers**:
  - Code module achieves 100% test pass rate, $>90\%$ coverage, and 0 security vulnerabilities.
  - Architecture blueprint demonstrates high modularity and zero refactoring cycles.
- **Harvesting Actions**:
  1. Extract structural template, anonymize domain specifics, and generalize parameters.
  2. Write new reusable SOP or design pattern manifest into `knowledge/sops/` or `knowledge/best_practices/`.
  3. Index code snippet into the Reusable Component Library.

### Phase 5: Knowledge Base Indexing & Policy Evolution
- **Responsible Agents**: `A11 Compliance & Governance`, `A12 Continuous Learning & Reflection`
- **Indexing Actions**:
  1. Compute dense vector embeddings for newly harvested SOPs, post-mortems, and patterns.
  2. Update semantic search vector index used by agents during RAG context retrieval.
  3. Propose updates to runtime policies (`policies/coding_policies.yaml`, `policies/security_policies.yaml`) if systemic risks are discovered.

---

## 4. Safety Guardrails for Autonomous Self-Improvement

To prevent prompt drift, hallucinations, or governance degradation during autonomous self-improvement:

1. **Immutable Core Guardrails**: Core security boundaries, authorization matrices, and ethical guidelines are hardcoded and cannot be modified by the learning workflow.
2. **Benchmark Regression Suitability**: No prompt update or workflow change can be promoted without passing 100% of the gold-standard system regression suite.
3. **Policy Modification Gating**: Proposed changes to `policies/*.yaml` require explicit `A11 Compliance Agent` audit sign-off and mandatory human-in-the-loop approval.
